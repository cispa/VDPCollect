let taintDataBatch = []; // Store batched taint data
let debounceTimeout;     // Timeout for debouncing the send function

// Maximum number of items in a single batch
const MAX_BATCH_SIZE = 100; // You can adjust this number based on your payload limits

// Function to store taint data and trigger batch sending with debounce
function storeTaint(event) {
    const taintDataArray = event.detail.str.taint || [];  // Safely access taintData and default to empty array if undefined

    // Loop over each entry in the taintDataArray
    taintDataArray.forEach((entry) => {
        const taintData = {
            url: window.location.href,
            details: event.detail,
            taintFlows: entry, // Individual flow from taintDataArray
            source: entry['flow'].filter(step => step.source === true).map(step => step.operation)[0],
            sink: event.detail.sink,
        };

        // Add each taintData object to the batch array
        taintDataBatch.push(taintData);
    });

    // Debounce the send function to send the batch after 100ms
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
        sendBatchToBackend();  // Send batch when debounce time is over
    }, 100);
}

// Function to split the batch and send data to the backend in smaller chunks
function sendBatchToBackend() {
    if (taintDataBatch.length === 0) return;  // If no data in batch, return

    // Log the batch data size for debugging
    console.log(`Sending batch with ${taintDataBatch.length} entries`);

    // Split the batch into smaller chunks
    const chunks = chunkArray(taintDataBatch, MAX_BATCH_SIZE);

    // Send each chunk separately
    chunks.forEach((chunk, index) => {
        sendChunkToBackend(chunk, index + 1, chunks.length);
    });

    // Clear the batch after sending
    taintDataBatch = [];
}

// Function to split the array into smaller chunks
function chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size));
    }
    return chunks;
}

// Function to send a single chunk to the backend
function sendChunkToBackend(chunk, chunkIndex, totalChunks) {
    console.log(`Sending chunk ${chunkIndex} of ${totalChunks} with ${chunk.length} entries`);

    fetch('http://localhost:8000/taintreport', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(chunk), // Send the chunk of batched data to the server
    })
    .then(response => response.json())
    .then(responseData => {
        console.log(`Successfully sent chunk ${chunkIndex} of ${totalChunks}:`, responseData);
    })
    .catch(error => {
        console.error(`Error sending chunk ${chunkIndex} of ${totalChunks}:`, error);
    });
}

window.addEventListener("__taintreport", storeTaint);
